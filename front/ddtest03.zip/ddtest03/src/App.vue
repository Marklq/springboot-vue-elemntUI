<template xmlns="">
    <!--构建整个页面框架-->
    <el-container style="height: 500px; border: 1px solid #eee">

        <!--左边栏-->
        <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
            <!--左侧菜单内容-->
            <!-- :default-openeds ： 默认展开的菜单，通过index值来进行关联-->
            <!-- :default-active ： 默认选中的菜单，通过index来进行关联-->
            <!--<el-menu :default-openeds="['1', '3']">-->
            <!--           <el-menu :default-openeds="['1']" :default-active="'1-1'">

                           &lt;!&ndash;
                           可展开的菜单栏。
                           index：菜单的下标，文本类型，不能是数值类型。
                           &ndash;&gt;
                           <el-submenu index="1">
                               &lt;!&ndash;el-submenu的菜单名
                                   i: 设置图标
                               &ndash;&gt;
                               <template slot="title"><i class="el-icon-message"></i>导航一</template>

                               <el-menu-item-group>
                                   <template slot="title">分组一</template>
                                   &lt;!&ndash;菜单子节点。不能再展开
                                       index：
                                   &ndash;&gt;
                                   <el-menu-item index="1-1">选项1</el-menu-item>
                                   <el-menu-item index="1-2">选项2</el-menu-item>
                               </el-menu-item-group>

                               <el-menu-item-group title="分组2">
                                   <el-submenu index="1-3">
                                       <template slot="title">选项3</template>
                                       <el-menu-item index="1-3-1">选项3-1</el-menu-item>
                                       <el-menu-item index="1-3-2">选项3-2</el-menu-item>
                                       <el-menu-item index="1-3-3">选项3-3</el-menu-item>
                                   </el-submenu>
                               </el-menu-item-group>


                           </el-submenu>

                       </el-menu>-->

            <!--动态生成菜单-->
            <el-menu router :default-openeds="['0','1']">
                <el-submenu v-for="(item,index)  in $router.options.routes" :index="index+''" v-if="item.show">
                    <template slot="title"><i class="el-icon-setting"></i>{{item.name}}</template>
                    <el-menu-item v-for="item2 in item.children" :index="item2.path"
                                  :class="$route.path==item2.path?'is-active':''">
                        {{item2.name}}
                    </el-menu-item>
                </el-submenu>
            </el-menu>
        </el-aside>

        <el-main>
            <router-view></router-view>
        </el-main>
    </el-container>


    <!--    &lt;!&ndash;构建整个页面框架&ndash;&gt;
        <el-container style="height: 500px; border: 1px solid #eee">

            &lt;!&ndash;左边栏&ndash;&gt;
            <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
                &lt;!&ndash;左侧菜单内容&ndash;&gt;
                &lt;!&ndash; :default-openeds ： 默认展开的菜单，通过index值来进行关联&ndash;&gt;
                &lt;!&ndash; :default-active ： 默认选中的菜单，通过index来进行关联&ndash;&gt;
                &lt;!&ndash;<el-menu :default-openeds="['1', '3']">&ndash;&gt;
                &lt;!&ndash;           <el-menu :default-openeds="['1']" :default-active="'1-1'">

                               &lt;!&ndash;
                               可展开的菜单栏。
                               index：菜单的下标，文本类型，不能是数值类型。
                               &ndash;&gt;
                               <el-submenu index="1">
                                   &lt;!&ndash;el-submenu的菜单名
                                       i: 设置图标
                                   &ndash;&gt;
                                   <template slot="title"><i class="el-icon-message"></i>导航一</template>

                                   <el-menu-item-group>
                                       <template slot="title">分组一</template>
                                       &lt;!&ndash;菜单子节点。不能再展开
                                           index：
                                       &ndash;&gt;
                                       <el-menu-item index="1-1">选项1</el-menu-item>
                                       <el-menu-item index="1-2">选项2</el-menu-item>
                                   </el-menu-item-group>

                                   <el-menu-item-group title="分组2">
                                       <el-submenu index="1-3">
                                           <template slot="title">选项3</template>
                                           <el-menu-item index="1-3-1">选项3-1</el-menu-item>
                                           <el-menu-item index="1-3-2">选项3-2</el-menu-item>
                                           <el-menu-item index="1-3-3">选项3-3</el-menu-item>
                                       </el-submenu>
                                   </el-menu-item-group>


                               </el-submenu>

                           </el-menu>&ndash;&gt;

                &lt;!&ndash;动态生成菜单&ndash;&gt;
                <el-menu>
                    <el-submenu v-for="(item,index)  in $router.options.routes" :index="index+''">
                        <template slot="title"><i class="el-icon-setting"></i>{{item.name}}</template>
                        <el-menu-item v-for="(item2,index2) in item.children" :index="index+'-'+index2">{{item2.name}}
                        </el-menu-item>
                    </el-submenu>
                </el-menu>

            </el-aside>

            <el-container>
                <el-header style="text-align: right; font-size: 12px">
                    <el-dropdown>
                        <i class="el-icon-setting" style="margin-right: 15px"></i>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item>查看</el-dropdown-item>
                            <el-dropdown-item>新增</el-dropdown-item>
                            <el-dropdown-item>删除</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                    <span>王小虎</span>
                </el-header>

                <el-main>
                    <router-view>
                    </router-view>
                </el-main>
            </el-container>
        </el-container>-->
</template>

<style>
</style>

<script>
</script>
