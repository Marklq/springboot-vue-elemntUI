<template>
    <h1>这是页面3</h1>

</template>

<script>
    export default {
        name: "page3"
    }
</script>

<style scoped>

</style>