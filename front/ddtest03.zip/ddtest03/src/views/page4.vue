<template>
    <h1>这是页面4</h1>
</template>

<script>
    export default {
        name: "page4"
    }
</script>

<style scoped>

</style>