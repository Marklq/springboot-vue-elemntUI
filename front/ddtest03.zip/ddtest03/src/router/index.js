import Vue from 'vue'
import VueRouter from 'vue-router'
import Page1 from '../views/page1'
import Page2 from '../views/page2'
import Page3 from '../views/page3'
import Page4 from '../views/page4'
import Index from '../views/index'
import Update from '../views/Update'

Vue.use(VueRouter);

const routes = [
    {
        path: '/',
        name: '图书管理',
        show: true,
        component: Index,
        redirect: '/page1',
        children: [
            {
                path: '/page1',
                name: '查询所有',
                component: Page1
            },
            {
                path: '/page2',
                name: '添加',
                component: Page2
            }
        ]
    },
    {
        path: '/update',
        show: false,
        component: Update,
    },
    {
        path: '/navigation',
        name: '导航二',
        show: true,
        component: Index,
        children: [
            {
                path: '/page3',
                name: '页面3',
                component: Page3
            },
            {
                path: '/page4',
                name: '页面4',
                component: Page4
            }
        ]
    }

]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router
